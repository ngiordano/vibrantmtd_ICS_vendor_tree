package mobi.cyann.nstools;


public class NSTweakFragment extends BasePreferenceFragment {
	//private final static String LOG_TAG = "NSTools.NSTweakActivity";
	
	public NSTweakFragment() {
		super(R.layout.ns_tweak);
	}
}
